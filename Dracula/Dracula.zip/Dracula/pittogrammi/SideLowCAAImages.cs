using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using UnityEngine;

public class SideLowCAAImages : MonoBehaviour
{
    [Header("Riferimenti")]
    [SerializeField] private UIObjectSpawner uiObjectSpawner;

    [Header("Percorso sorgente (ARASAAC locale)")]
    public string localArasaacFolder = @"C:\Users\Danielee\Pictures\ARASAAC_IT";

    [Header("Percorso destinazione (Unity Resources)")]
    public string relativeSavePath = "Resources/LibritaClean/immaginitest/illusimage/ImmaginiCAA";

    private string unityDestinationPath;

    private void Start()
    {
        if (uiObjectSpawner == null)
            uiObjectSpawner = FindObjectOfType<UIObjectSpawner>();

        unityDestinationPath = Path.Combine(Application.dataPath, relativeSavePath);

        if (!Directory.Exists(unityDestinationPath))
        {
            Directory.CreateDirectory(unityDestinationPath);
            Debug.Log("[CAA COPY] Creata cartella destinazione: " + unityDestinationPath);
        }

        StartCoroutine(ProcessWordsRoutine());
    }



    private IEnumerator ProcessWordsRoutine()
    {
        Debug.Log("[CAA COPY] In attesa che UIObjectSpawner carichi il JSON...");

        while (!uiObjectSpawner.HasLoadedJson)
            yield return null;

        Debug.Log("[CAA COPY] JSON pronto. Recupero testi...");

        List<string> allTexts = uiObjectSpawner.GetAllTexts();
        if (allTexts == null || allTexts.Count == 0)
        {
            Debug.LogWarning("[CAA COPY] Nessun testo trovato.");
            yield break;
        }


        // =============================
        // ESTRAZIONE PAROLE
        // =============================

        HashSet<string> words = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        Regex regex = new Regex(@"\p{L}+", RegexOptions.CultureInvariant);

        foreach (string line in allTexts)
        {
            foreach (Match m in regex.Matches(line))
            {
                string w = m.Value.ToLower();
                if (!string.IsNullOrWhiteSpace(w))
                    words.Add(w);
            }
        }

        Debug.Log("[CAA COPY] Parole uniche trovate: " + words.Count);


        // =============================
        // COPIA LOCALE
        // =============================

        foreach (string word in words)
        {
            CopyLocalPictogram(word);
            yield return null; // evita freeze Editor
        }

        Debug.Log("[CAA COPY] COMPLETATO.");
    }



    private void CopyLocalPictogram(string word)
    {
        if (string.IsNullOrEmpty(word))
            return;

        string firstLetter = word.Substring(0, 1).ToUpper();

        string sourceFolder = Path.Combine(localArasaacFolder, firstLetter);
        if (!Directory.Exists(sourceFolder))
        {
            Debug.LogWarning($"[CAA COPY] Cartella non trovata: {sourceFolder}");
            return;
        }

        // cerca file che iniziano con la parola
        string[] files = Directory.GetFiles(sourceFolder, word + "*.png", SearchOption.TopDirectoryOnly);

        if (files.Length == 0)
        {
            Debug.LogWarning($"[CAA COPY] Nessun file trovato per parola: {word}");
            return;
        }

        // prendi il primo trovato
        string sourceFile = files[0];

        string destFile = Path.Combine(unityDestinationPath, word + ".png");

        try
        {
            File.Copy(sourceFile, destFile, overwrite: true);
            Debug.Log($"[CAA COPY] Copiato: {word} ? {destFile}");
        }
        catch (Exception e)
        {
            Debug.LogError($"[CAA COPY] Errore copia '{word}': {e.Message}");
        }
    }
}
